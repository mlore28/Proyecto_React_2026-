import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useAuth } from "../../context/AuthContext";

export const Route = createFileRoute("/_authenticated/perfil")({
  head: () => ({
    meta: [
      { title: "Mi perfil — anthea" },
      { name: "description", content: "Datos de tu cuenta y accesos de anthea." },
      { property: "og:title", content: "Mi perfil — anthea" },
      { property: "og:description", content: "Datos de tu cuenta y accesos de anthea." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Perfil,
});

type AuthUser = { id: string; email: string; name: string; role: "user" | "admin" };

function Perfil() {
  const { user, isAdmin, loading, error, logout } = useAuth() as {
    user: AuthUser | null;
    isAdmin: boolean;
    loading: boolean;
    error: string;
    logout: () => Promise<void>;
  };
  const { queryClient } = Route.useRouteContext();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await logout();
    navigate({ to: "/acceso", replace: true });
  };

  if (loading || !user) return <p className="muted" role="status">Cargando perfil...</p>;

  return (
    <section className="profile-card">
      <p className="eyebrow">Cuenta</p>
      <h1 className="h1">Hola, {user.name}</h1>
      <dl className="profile-data">
        <div><dt>Correo</dt><dd>{user.email}</dd></div>
        <div><dt>Rol</dt><dd>{isAdmin ? "Administrador" : "Usuario"}</dd></div>
      </dl>
      {error && <p className="notice warning">{error}</p>}
      <div className="row">
        {isAdmin && <Link to="/gestion" className="btn">Gestionar servicios</Link>}
        <button className="btn btn-outline" onClick={handleSignOut}>Cerrar sesión</button>
      </div>
    </section>
  );
}
