import { createFileRoute } from "@tanstack/react-router";
import AdminPanel from "../../components/AdminPanel";
import { useAuth } from "../../context/AuthContext";

export const Route = createFileRoute("/_authenticated/gestion")({
  head: () => ({
    meta: [
      { title: "Gestión de servicios — anthea" },
      { name: "description", content: "Creación, edición y eliminación de servicios del catálogo de anthea." },
      { property: "og:title", content: "Gestión de servicios — anthea" },
      { property: "og:description", content: "Creación, edición y eliminación de servicios del catálogo de anthea." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Gestion,
});

function Gestion() {
  const { isAdmin, loading } = useAuth();

  if (loading) return <p className="muted" role="status">Verificando permisos...</p>;
  if (!isAdmin) {
    return (
      <section className="empty">
        <p className="eyebrow">Acceso restringido</p>
        <h1 className="h1">Esta sección es solo para administradores</h1>
        <p className="lead">Tu cuenta puede ver el catálogo, pero no modificarlo.</p>
      </section>
    );
  }

  return (
    <>
      <p className="eyebrow">Administración</p>
      <h1 className="h1">Gestión de servicios</h1>
      <p className="lead">Creá, editá o eliminá servicios. Los cambios se guardan en Firestore.</p>
      <AdminPanel />
    </>
  );
}
