import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { isFirebaseConfigured } from "../../lib/firebase-config";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    const loginRedirect = () =>
      redirect({ to: "/acceso", search: { redirect: location.href } });

    if (!isFirebaseConfigured) throw loginRedirect();
    const { getFirebase } = await import("../../lib/firebase");
    const { auth } = getFirebase();
    await auth.authStateReady();
    if (!auth.currentUser) throw loginRedirect();
  },
  component: () => <Outlet />,
});
