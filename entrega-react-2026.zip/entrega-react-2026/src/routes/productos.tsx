import { createFileRoute } from "@tanstack/react-router";
import ItemListContainer from "../components/ItemListContainer";

export const Route = createFileRoute("/productos")({
  head: () => ({
    meta: [
      { title: "Servicios — anthea" },
      { name: "description", content: "Catálogo de servicios: staffing IT, Odoo, consultoría y desarrollo." },
      { property: "og:title", content: "Servicios — anthea" },
      { property: "og:description", content: "Catálogo de servicios: staffing IT, Odoo, consultoría y desarrollo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <>
      <h1 className="h1">Nuestros servicios</h1>
      <ItemListContainer />
    </>
  ),
});
