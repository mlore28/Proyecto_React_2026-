import { createFileRoute } from "@tanstack/react-router";
import AuthForms from "../components/AuthForms";

export const Route = createFileRoute("/acceso")({
  validateSearch: (search: Record<string, unknown>): { redirect?: string } => {
    const redirect = search["redirect"];
    return typeof redirect === "string" && redirect.startsWith("/") && !redirect.startsWith("//")
      ? { redirect }
      : {};
  },
  head: () => ({
    meta: [
      { title: "Ingresar o crear cuenta — anthea" },
      { name: "description", content: "Ingresá a tu cuenta de anthea o registrate con tu correo." },
      { property: "og:title", content: "Ingresar o crear cuenta — anthea" },
      { property: "og:description", content: "Ingresá a tu cuenta de anthea o registrate con tu correo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Acceso,
});

function Acceso() {
  const { redirect } = Route.useSearch();
  return (
    <>
      <p className="eyebrow">Tu cuenta</p>
      <h1 className="h1">Bienvenido a anthea</h1>
      <p className="lead">Ingresá para ver tu perfil y acceder a las funciones de tu cuenta.</p>
      <AuthForms redirectTo={redirect} />
    </>
  );
}
