import { createFileRoute } from "@tanstack/react-router";
import ItemDetail from "../components/ItemDetail";

export const Route = createFileRoute("/producto/$id")({
  head: () => ({
    meta: [
      { title: "Detalle del servicio — anthea" },
      { name: "description", content: "Conocé el detalle y precio de este servicio de anthea." },
      { property: "og:title", content: "Detalle del servicio — anthea" },
      { property: "og:description", content: "Conocé el detalle y precio de este servicio de anthea." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Detalle,
});

function Detalle() {
  const { id } = Route.useParams();
  return <ItemDetail id={id} />;
}
