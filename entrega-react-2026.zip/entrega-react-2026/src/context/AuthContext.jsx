import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { isFirebaseConfigured } from "../lib/firebase-config";
import { firebaseErrorMessage } from "../lib/firebase-errors";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const router = useRouter();

  useEffect(() => {
    if (!isFirebaseConfigured) {
      setLoading(false);
      return;
    }

    let active = true;
    let unsubscribe;

    Promise.all([import("firebase/auth"), import("firebase/firestore"), import("../lib/firebase")])
      .then(([authApi, firestoreApi, { getFirebase }]) => {
        const { auth, db } = getFirebase();
        unsubscribe = authApi.onAuthStateChanged(auth, async (firebaseUser) => {
          if (!active) return;

          if (!firebaseUser) {
            setUser(null);
            setLoading(false);
            router.invalidate();
            return;
          }

          try {
            const [profileSnapshot, roleSnapshot] = await Promise.all([
              firestoreApi.getDoc(firestoreApi.doc(db, "users", firebaseUser.uid)),
              firestoreApi.getDoc(firestoreApi.doc(db, "roles", firebaseUser.uid)),
            ]);
            if (!active) return;
            const profile = profileSnapshot.data();
            const role = roleSnapshot.data()?.role === "admin" ? "admin" : "user";
            setUser({
              id: firebaseUser.uid,
              email: firebaseUser.email || profile?.email || "",
              name: profile?.nombre || firebaseUser.displayName || "Usuario",
              role,
            });
            setError("");
          } catch (authError) {
            if (!active) return;
            setUser({
              id: firebaseUser.uid,
              email: firebaseUser.email || "",
              name: firebaseUser.displayName || "Usuario",
              role: "user",
            });
            setError(firebaseErrorMessage(authError));
          } finally {
            if (active) {
              setLoading(false);
              router.invalidate();
            }
          }
        });
      })
      .catch((authError) => {
        if (!active) return;
        setError(firebaseErrorMessage(authError));
        setLoading(false);
      });

    return () => {
      active = false;
      unsubscribe?.();
    };
  }, [router]);

  const login = async (email, password) => {
    const [{ signInWithEmailAndPassword }, { getFirebase }] = await Promise.all([
      import("firebase/auth"),
      import("../lib/firebase"),
    ]);
    const { auth } = getFirebase();
    await signInWithEmailAndPassword(auth, email.trim(), password);
  };

  const register = async (name, email, password) => {
    const cleanName = name.trim();
    if (cleanName.length < 2 || cleanName.length > 80) {
      throw new Error("El nombre debe tener entre 2 y 80 caracteres.");
    }
    if (password.length < 6) throw new Error("La contraseña debe tener al menos 6 caracteres.");

    const [authApi, firestoreApi, { getFirebase }] = await Promise.all([
      import("firebase/auth"),
      import("firebase/firestore"),
      import("../lib/firebase"),
    ]);
    const { auth, db } = getFirebase();
    const credential = await authApi.createUserWithEmailAndPassword(auth, email.trim(), password);
    await authApi.updateProfile(credential.user, { displayName: cleanName });
    await Promise.all([
      firestoreApi.setDoc(firestoreApi.doc(db, "users", credential.user.uid), {
        nombre: cleanName,
        email: email.trim(),
        createdAt: firestoreApi.serverTimestamp(),
      }),
      firestoreApi.setDoc(firestoreApi.doc(db, "roles", credential.user.uid), { role: "user" }),
    ]);
    setUser({ id: credential.user.uid, email: email.trim(), name: cleanName, role: "user" });
    setLoading(false);
  };

  const logout = async () => {
    const [{ signOut }, { getFirebase }] = await Promise.all([
      import("firebase/auth"),
      import("../lib/firebase"),
    ]);
    await signOut(getFirebase().auth);
  };

  const value = useMemo(
    () => ({
      user,
      loading,
      error,
      isAuthenticated: Boolean(user),
      isAdmin: user?.role === "admin",
      login,
      register,
      logout,
    }),
    [user, loading, error],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth debe usarse dentro de AuthProvider");
  return context;
}
