import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { cleanProductInput } from "../lib/catalog";
import { isFirebaseConfigured } from "../lib/firebase-config";
import { firebaseErrorMessage } from "../lib/firebase-errors";

const ProductsContext = createContext(null);

function normalizeLocalProduct(product) {
  return { ...product, id: String(product.id) };
}

export function ProductsProvider({ children }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    let unsubscribe;

    if (!isFirebaseConfigured) {
      fetch("/productos.json")
        .then((response) => {
          if (!response.ok) throw new Error("No se pudieron cargar los servicios.");
          return response.json();
        })
        .then((data) => {
          if (active) setProducts(data.map(normalizeLocalProduct));
        })
        .catch((loadError) => {
          if (active) setError(firebaseErrorMessage(loadError));
        })
        .finally(() => {
          if (active) setLoading(false);
        });
    } else {
      Promise.all([import("firebase/firestore"), import("../lib/firebase")])
        .then(([firestoreApi, { getFirebase }]) => {
          if (!active) return;
          const { db } = getFirebase();
          unsubscribe = firestoreApi.onSnapshot(
            firestoreApi.collection(db, "products"),
            (snapshot) => {
              setProducts(snapshot.docs.map((document) => ({ id: document.id, ...document.data() })));
              setError("");
              setLoading(false);
            },
            (loadError) => {
              if (!active) return;
              setError(firebaseErrorMessage(loadError));
              setLoading(false);
            },
          );
        })
        .catch((loadError) => {
          if (!active) return;
          setError(firebaseErrorMessage(loadError));
          setLoading(false);
        });
    }

    return () => {
      active = false;
      unsubscribe?.();
    };
  }, []);

  const addProduct = async (input) => {
    const [firestoreApi, { getFirebase }] = await Promise.all([
      import("firebase/firestore"),
      import("../lib/firebase"),
    ]);
    const { db } = getFirebase();
    await firestoreApi.addDoc(firestoreApi.collection(db, "products"), {
      ...cleanProductInput(input),
      createdAt: firestoreApi.serverTimestamp(),
      updatedAt: firestoreApi.serverTimestamp(),
    });
  };

  const updateProduct = async (id, input) => {
    const [firestoreApi, { getFirebase }] = await Promise.all([
      import("firebase/firestore"),
      import("../lib/firebase"),
    ]);
    const { db } = getFirebase();
    await firestoreApi.updateDoc(firestoreApi.doc(db, "products", id), {
      ...cleanProductInput(input),
      updatedAt: firestoreApi.serverTimestamp(),
    });
  };

  const deleteProduct = async (id) => {
    const [firestoreApi, { getFirebase }] = await Promise.all([
      import("firebase/firestore"),
      import("../lib/firebase"),
    ]);
    await firestoreApi.deleteDoc(firestoreApi.doc(getFirebase().db, "products", id));
  };

  const seedProducts = async () => {
    const response = await fetch("/productos.json");
    if (!response.ok) throw new Error("No se pudo cargar el catálogo inicial.");
    const initialProducts = await response.json();
    const [firestoreApi, { getFirebase }] = await Promise.all([
      import("firebase/firestore"),
      import("../lib/firebase"),
    ]);
    const { db } = getFirebase();
    const batch = firestoreApi.writeBatch(db);
    initialProducts.forEach((product) => {
      const document = firestoreApi.doc(db, "products", `servicio-${product.id}`);
      const { id, ...input } = normalizeLocalProduct(product);
      batch.set(document, {
        ...cleanProductInput(input),
        createdAt: firestoreApi.serverTimestamp(),
        updatedAt: firestoreApi.serverTimestamp(),
      });
    });
    await batch.commit();
  };

  const value = useMemo(
    () => ({ products, loading, error, isFirebaseConfigured, addProduct, updateProduct, deleteProduct, seedProducts }),
    [products, loading, error],
  );

  return <ProductsContext.Provider value={value}>{children}</ProductsContext.Provider>;
}

export function useProducts() {
  const context = useContext(ProductsContext);
  if (!context) throw new Error("useProducts debe usarse dentro de ProductsProvider");
  return context;
}
