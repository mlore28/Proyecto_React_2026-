export type ProductInput = {
  nombre: string;
  categoria: string;
  precio: number;
  unidad: string;
  descripcion: string;
  icono: string;
};

export function validateProduct(input: ProductInput) {
  const errors: Partial<Record<keyof ProductInput, string>> = {};

  if (!input.nombre.trim()) errors.nombre = "El nombre es obligatorio.";
  else if (input.nombre.trim().length > 120) errors.nombre = "El nombre no puede superar 120 caracteres.";
  if (!input.categoria.trim()) errors.categoria = "La categoría es obligatoria.";
  if (!Number.isFinite(input.precio) || input.precio <= 0) errors.precio = "El precio debe ser mayor que cero.";
  else if (input.precio > 10_000_000) errors.precio = "El precio no puede superar 10.000.000.";
  if (!input.unidad.trim()) errors.unidad = "La unidad es obligatoria.";
  if (!input.descripcion.trim()) errors.descripcion = "La descripción es obligatoria.";
  else if (input.descripcion.trim().length > 500) errors.descripcion = "La descripción no puede superar 500 caracteres.";
  if (input.icono.length > 8) errors.icono = "Usá un solo ícono o emoji.";

  return errors;
}

export function cleanProductInput(input: ProductInput): ProductInput {
  const errors = validateProduct(input);
  const firstError = Object.values(errors)[0];
  if (firstError) throw new Error(firstError);

  return {
    nombre: input.nombre.trim(),
    categoria: input.categoria.trim(),
    precio: input.precio,
    unidad: input.unidad.trim(),
    descripcion: input.descripcion.trim(),
    icono: input.icono.trim() || "✦",
  };
}

export function filterProducts<T extends { nombre: string; categoria: string; descripcion: string }>(
  products: T[],
  query: string,
) {
  const normalize = (value: string) =>
    value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  const term = normalize(query);
  if (!term) return products;

  return products.filter((product) =>
    normalize(`${product.nombre} ${product.categoria} ${product.descripcion}`).includes(term),
  );
}

export function paginate<T>(items: T[], requestedPage: number, pageSize = 4) {
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const page = Math.min(Math.max(1, Math.floor(requestedPage) || 1), totalPages);
  return {
    items: items.slice((page - 1) * pageSize, page * pageSize),
    page,
    totalPages,
  };
}
