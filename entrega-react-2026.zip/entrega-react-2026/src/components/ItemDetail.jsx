import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useCart } from "../context/CartContext";
import { useProducts } from "../context/ProductsContext";

export default function ItemDetail({ id }) {
  const [agregado, setAgregado] = useState(false);
  const { addToCart } = useCart();
  const { products, loading, error } = useProducts();
  const producto = products.find((product) => String(product.id) === String(id));

  if (loading) return <p className="muted" role="status">Cargando...</p>;
  if (error) return <p className="notice error" role="alert">{error}</p>;
  if (!producto) return <p className="muted">Servicio no encontrado. <Link to="/productos">Volver</Link></p>;

  return (
    <div className="detail">
      <div className="detail-icon" aria-hidden="true">{producto.icono}</div>
      <div>
        <span className="tag">{producto.categoria}</span>
        <h1 className="h1">{producto.nombre}</h1>
        <p className="lead">{producto.descripcion}</p>
        <p className="price big">USD {Number(producto.precio).toLocaleString("es-AR")} <span className="muted small">/ {producto.unidad}</span></p>
        <div className="row">
          <button className="btn" onClick={() => { addToCart(producto); setAgregado(true); }}>Agregar al carrito</button>
          <Link to="/productos" className="btn btn-outline">Volver</Link>
        </div>
        {agregado && <p className="ok" role="status">✓ Agregado al carrito</p>}
      </div>
    </div>
  );
}
