import { useEffect, useState } from "react";
import { validateProduct } from "../lib/catalog";

const emptyProduct = {
  nombre: "",
  categoria: "",
  precio: "",
  unidad: "proyecto",
  descripcion: "",
  icono: "✦",
};

export default function ProductForm({ product, saving, onSubmit, onCancel }) {
  const [form, setForm] = useState(emptyProduct);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    setForm(product ? { ...product, precio: String(product.precio) } : emptyProduct);
    setErrors({});
  }, [product]);

  const updateField = (event) => {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
    setErrors((current) => ({ ...current, [name]: undefined }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const input = { ...form, precio: Number(form.precio) };
    const nextErrors = validateProduct(input);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    await onSubmit(input);
  };

  return (
    <form className="form product-form" onSubmit={handleSubmit} noValidate>
      <div className="form-heading">
        <h2>{product ? "Editar servicio" : "Agregar servicio"}</h2>
        <p className="muted">Todos los campos son obligatorios excepto el ícono.</p>
      </div>
      <div className="form-grid">
        <div className="field field-wide">
          <label htmlFor="product-name">Nombre</label>
          <input id="product-name" name="nombre" value={form.nombre} onChange={updateField} maxLength={120} aria-invalid={Boolean(errors.nombre)} />
          {errors.nombre && <span className="field-error">{errors.nombre}</span>}
        </div>
        <div className="field">
          <label htmlFor="product-category">Categoría</label>
          <input id="product-category" name="categoria" value={form.categoria} onChange={updateField} maxLength={60} aria-invalid={Boolean(errors.categoria)} />
          {errors.categoria && <span className="field-error">{errors.categoria}</span>}
        </div>
        <div className="field">
          <label htmlFor="product-price">Precio en USD</label>
          <input id="product-price" name="precio" type="number" min="1" max="10000000" step="1" value={form.precio} onChange={updateField} aria-invalid={Boolean(errors.precio)} />
          {errors.precio && <span className="field-error">{errors.precio}</span>}
        </div>
        <div className="field">
          <label htmlFor="product-unit">Unidad</label>
          <select id="product-unit" name="unidad" value={form.unidad} onChange={updateField}>
            <option value="proyecto">proyecto</option>
            <option value="mes">mes</option>
            <option value="hora">hora</option>
          </select>
        </div>
        <div className="field">
          <label htmlFor="product-icon">Ícono</label>
          <input id="product-icon" name="icono" value={form.icono} onChange={updateField} maxLength={8} aria-invalid={Boolean(errors.icono)} />
          {errors.icono && <span className="field-error">{errors.icono}</span>}
        </div>
        <div className="field field-wide">
          <label htmlFor="product-description">Descripción</label>
          <textarea id="product-description" name="descripcion" value={form.descripcion} onChange={updateField} maxLength={500} rows={4} aria-invalid={Boolean(errors.descripcion)} />
          {errors.descripcion && <span className="field-error">{errors.descripcion}</span>}
        </div>
      </div>
      <div className="row">
        <button className="btn" type="submit" disabled={saving}>{saving ? "Guardando..." : product ? "Guardar cambios" : "Agregar servicio"}</button>
        <button className="btn btn-outline" type="button" onClick={onCancel} disabled={saving}>Cancelar</button>
      </div>
    </form>
  );
}
