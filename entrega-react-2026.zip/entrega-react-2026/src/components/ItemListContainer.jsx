import { useEffect, useMemo, useState } from "react";
import Item from "./Item";
import { useProducts } from "../context/ProductsContext";
import { filterProducts, paginate } from "../lib/catalog";

export default function ItemListContainer() {
  const { products, loading, error } = useProducts();
  const [query, setQuery] = useState("");
  const [requestedPage, setRequestedPage] = useState(1);

  useEffect(() => setRequestedPage(1), [query]);

  const filteredProducts = useMemo(() => filterProducts(products, query), [products, query]);
  const pagination = useMemo(() => paginate(filteredProducts, requestedPage, 4), [filteredProducts, requestedPage]);

  if (loading) return <p className="muted" role="status">Cargando servicios...</p>;
  if (error) return <p className="notice error" role="alert">{error}</p>;

  return (
    <div className="catalog">
      <div className="search-field">
        <label htmlFor="product-search">Buscar servicios</label>
        <input
          id="product-search"
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Ej.: Odoo, staffing o consultoría"
          autoComplete="off"
        />
        <p className="muted small" aria-live="polite">
          {filteredProducts.length} {filteredProducts.length === 1 ? "servicio encontrado" : "servicios encontrados"}
        </p>
      </div>

      {pagination.items.length > 0 ? (
        <div className="grid">
          {pagination.items.map((product) => <Item key={product.id} {...product} />)}
        </div>
      ) : (
        <div className="empty">
          <p className="lead">No encontramos servicios para “{query}”.</p>
          <button className="btn btn-outline" onClick={() => setQuery("")}>Limpiar búsqueda</button>
        </div>
      )}

      {pagination.totalPages > 1 && (
        <nav className="pagination" aria-label="Páginas de servicios">
          <button className="btn btn-small btn-outline" disabled={pagination.page === 1} onClick={() => setRequestedPage(pagination.page - 1)}>Anterior</button>
          {Array.from({ length: pagination.totalPages }, (_, index) => index + 1).map((page) => (
            <button
              key={page}
              className={page === pagination.page ? "page-button active" : "page-button"}
              aria-label={`Página ${page}`}
              aria-current={page === pagination.page ? "page" : undefined}
              onClick={() => setRequestedPage(page)}
            >
              {page}
            </button>
          ))}
          <button className="btn btn-small btn-outline" disabled={pagination.page === pagination.totalPages} onClick={() => setRequestedPage(pagination.page + 1)}>Siguiente</button>
        </nav>
      )}
    </div>
  );
}
