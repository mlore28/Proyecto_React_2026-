import { Link } from "@tanstack/react-router";
import CartWidget from "./CartWidget";
import { useAuth } from "../context/AuthContext";

export default function NavBar() {
  const { isAuthenticated, isAdmin, loading, user } = useAuth();

  return (
    <nav className="nav" aria-label="Navegación principal">
      <Link to="/" className="nav-link" activeProps={{ className: "nav-link active" }} activeOptions={{ exact: true }}>Inicio</Link>
      <Link to="/productos" className="nav-link" activeProps={{ className: "nav-link active" }}>Servicios</Link>
      {isAdmin && <Link to="/gestion" className="nav-link" activeProps={{ className: "nav-link active" }}>Gestión</Link>}
      {!loading && (
        isAuthenticated ? (
          <Link to="/perfil" className="nav-link" activeProps={{ className: "nav-link active" }}>{user.name}</Link>
        ) : (
          <Link to="/acceso" className="nav-link" activeProps={{ className: "nav-link active" }}>Ingresar</Link>
        )
      )}
      <CartWidget />
    </nav>
  );
}
