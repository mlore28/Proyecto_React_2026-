import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useAuth } from "../context/AuthContext";
import { isFirebaseConfigured } from "../lib/firebase-config";
import { firebaseErrorMessage } from "../lib/firebase-errors";

export default function AuthForms({ redirectTo }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const { login, register, isAuthenticated, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && isAuthenticated) navigate({ to: redirectTo || "/perfil", replace: true });
  }, [loading, isAuthenticated, navigate, redirectTo]);

  const updateField = (event) => setForm((current) => ({ ...current, [event.target.name]: event.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    if (mode === "register" && form.name.trim().length < 2) {
      setError("Ingresá tu nombre (al menos 2 caracteres).");
      return;
    }
    if (form.password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres.");
      return;
    }

    setSubmitting(true);
    try {
      if (mode === "login") await login(form.email, form.password);
      else await register(form.name, form.email, form.password);
      navigate({ to: redirectTo || "/perfil", replace: true });
    } catch (submitError) {
      setError(firebaseErrorMessage(submitError));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="auth-card">
      <div className="auth-tabs" role="tablist" aria-label="Acceso a la cuenta">
        <button role="tab" aria-selected={mode === "login"} className={mode === "login" ? "auth-tab active" : "auth-tab"} onClick={() => { setMode("login"); setError(""); }}>Ingresar</button>
        <button role="tab" aria-selected={mode === "register"} className={mode === "register" ? "auth-tab active" : "auth-tab"} onClick={() => { setMode("register"); setError(""); }}>Crear cuenta</button>
      </div>

      {!isFirebaseConfigured && (
        <p className="notice warning" role="status">Para activar el acceso, copiá <code>.env.example</code> como <code>.env.local</code> y completá los datos de Firebase.</p>
      )}

      <form className="form" onSubmit={handleSubmit} noValidate>
        {mode === "register" && (
          <div className="field">
            <label htmlFor="auth-name">Nombre</label>
            <input id="auth-name" name="name" autoComplete="name" value={form.name} onChange={updateField} minLength={2} maxLength={80} required />
          </div>
        )}
        <div className="field">
          <label htmlFor="auth-email">Correo electrónico</label>
          <input id="auth-email" name="email" type="email" autoComplete="email" value={form.email} onChange={updateField} maxLength={255} required />
        </div>
        <div className="field">
          <label htmlFor="auth-password">Contraseña</label>
          <input id="auth-password" name="password" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} value={form.password} onChange={updateField} minLength={6} required />
        </div>
        {error && <p className="notice error" role="alert">{error}</p>}
        <button className="btn" type="submit" disabled={!isFirebaseConfigured || submitting || loading}>
          {submitting ? "Procesando..." : mode === "login" ? "Ingresar" : "Crear cuenta"}
        </button>
      </form>
    </section>
  );
}
