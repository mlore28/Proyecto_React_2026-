import { Link } from "@tanstack/react-router";
import NavBar from "./NavBar";

export default function Header() {
  return (
    <header className="header">
      <div className="site-container header-inner">
        <Link to="/" className="logo">anthea<span>.</span></Link>
        <NavBar />
      </div>
    </header>
  );
}
