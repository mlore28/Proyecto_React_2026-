import { useState } from "react";
import ProductForm from "./ProductForm";
import { useProducts } from "../context/ProductsContext";
import { firebaseErrorMessage } from "../lib/firebase-errors";

export default function AdminPanel() {
  const { products, loading, error, addProduct, updateProduct, deleteProduct, seedProducts } = useProducts();
  const [editing, setEditing] = useState(null);
  const [formVisible, setFormVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [actionError, setActionError] = useState("");
  const [feedback, setFeedback] = useState("");

  const runAction = async (action, successMessage) => {
    setSaving(true);
    setActionError("");
    setFeedback("");
    try {
      await action();
      setFeedback(successMessage);
      return true;
    } catch (actionError) {
      setActionError(firebaseErrorMessage(actionError));
      return false;
    } finally {
      setSaving(false);
    }
  };

  const handleSubmit = async (input) => {
    const saved = await runAction(
      () => (editing ? updateProduct(editing.id, input) : addProduct(input)),
      editing ? "Servicio actualizado correctamente." : "Servicio agregado correctamente.",
    );
    if (saved) {
      setEditing(null);
      setFormVisible(false);
    }
  };

  const handleDelete = async (product) => {
    if (!window.confirm(`¿Eliminar “${product.nombre}”? Esta acción no se puede deshacer.`)) return;
    await runAction(() => deleteProduct(product.id), "Servicio eliminado correctamente.");
  };

  return (
    <div className="admin-stack">
      <div className="section-actions">
        <button className="btn" onClick={() => { setEditing(null); setFormVisible(true); }}>Agregar servicio</button>
        {products.length === 0 && !loading && (
          <button className="btn btn-outline" disabled={saving} onClick={() => runAction(seedProducts, "Catálogo inicial cargado.")}>
            Cargar catálogo inicial
          </button>
        )}
      </div>

      {formVisible && (
        <ProductForm
          product={editing}
          saving={saving}
          onSubmit={handleSubmit}
          onCancel={() => { setEditing(null); setFormVisible(false); }}
        />
      )}

      {(error || actionError) && <p className="notice error" role="alert">{actionError || error}</p>}
      {feedback && <p className="notice success" role="status">{feedback}</p>}
      {loading ? <p className="muted" role="status">Cargando servicios...</p> : (
        <div className="admin-list">
          {products.map((product) => (
            <article className="admin-row" key={product.id}>
              <span className="cart-icon" aria-hidden="true">{product.icono}</span>
              <div>
                <h2 className="admin-name">{product.nombre}</h2>
                <p className="muted small">{product.categoria} · USD {Number(product.precio).toLocaleString("es-AR")} / {product.unidad}</p>
              </div>
              <div className="admin-actions">
                <button className="btn btn-small btn-outline" onClick={() => { setEditing(product); setFormVisible(true); }}>Editar</button>
                <button className="btn btn-small btn-danger" disabled={saving} onClick={() => handleDelete(product)}>Eliminar</button>
              </div>
            </article>
          ))}
          {products.length === 0 && <p className="muted">Todavía no hay servicios en Firestore.</p>}
        </div>
      )}
    </div>
  );
}
