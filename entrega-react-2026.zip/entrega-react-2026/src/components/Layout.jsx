import Header from "./Header";
import Footer from "./Footer";

export default function Layout({ children }) {
  return (
    <div className="layout">
      <Header />
      <main className="site-container main">{children}</main>
      <Footer />
    </div>
  );
}
