import { describe, expect, it } from "vitest";
import { filterProducts, paginate, validateProduct, type ProductInput } from "@/lib/catalog";

const validProduct: ProductInput = {
  nombre: "Implementación Odoo",
  categoria: "Odoo",
  precio: 4500,
  unidad: "proyecto",
  descripcion: "Puesta en marcha de Odoo ERP.",
  icono: "🧩",
};

describe("validación de servicios", () => {
  it("exige un nombre", () => {
    expect(validateProduct({ ...validProduct, nombre: " " }).nombre).toBe("El nombre es obligatorio.");
  });

  it("rechaza un precio igual a cero", () => {
    expect(validateProduct({ ...validProduct, precio: 0 }).precio).toBe("El precio debe ser mayor que cero.");
  });

  it("rechaza un precio negativo", () => {
    expect(validateProduct({ ...validProduct, precio: -10 }).precio).toBe("El precio debe ser mayor que cero.");
  });

  it("acepta el servicio Odoo de 4500 dólares", () => {
    expect(validateProduct(validProduct)).toEqual({});
  });
});

describe("búsqueda y paginación", () => {
  const products = [
    { ...validProduct, id: "1" },
    { ...validProduct, id: "2", nombre: "Staffing IT", categoria: "Staffing" },
    { ...validProduct, id: "3", nombre: "Consultoría", categoria: "Consultoría" },
    { ...validProduct, id: "4", nombre: "QA Analyst", categoria: "Staffing" },
    { ...validProduct, id: "5", nombre: "Soporte Odoo", categoria: "Odoo" },
    { ...validProduct, id: "6", nombre: "Desarrollo", categoria: "Desarrollo" },
  ];

  it("filtra en tiempo real ignorando mayúsculas y acentos", () => {
    expect(filterProducts(products, "consultoria").map((product) => product.id)).toEqual(["3"]);
  });

  it("divide seis servicios en páginas de cuatro", () => {
    expect(paginate(products, 1, 4).items.map((product) => product.id)).toEqual(["1", "2", "3", "4"]);
    expect(paginate(products, 2, 4).items.map((product) => product.id)).toEqual(["5", "6"]);
    expect(paginate(products, 2, 4).totalPages).toBe(2);
  });
});
